
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Documents.Client;
using Microsoft.Azure.Documents.Linq;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Host;

namespace DEVEBIAFUNCTIONS
{
    public static class Fame
    {
        [FunctionName("Fame")]
        public static IActionResult Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", Route = "fame/{id}")]
                HttpRequest req,
            [CosmosDB(
                databaseName: "contesthub",
                collectionName: "Fame",
                ConnectionStringSetting = "contesthub_DOCUMENTDB",
                SqlQuery = "select c.fameContestDetails from Fame c where upper(c.id)=upper({id})"
                )]
            IEnumerable<object> items,
            string id,
            TraceWriter log)
        {
            log.Info($"Processed request for {id} in Fame");

            if (items == null || !items.Any())
            {
                log.Info($"No data");
                return new NoContentResult();
            }
            else
            {

                return new OkObjectResult(items.First());

            }
        }
    }

}
