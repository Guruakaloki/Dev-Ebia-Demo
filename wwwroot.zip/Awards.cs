
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Documents.Client;
using Microsoft.Azure.Documents.Linq;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Host;

namespace DEVEBIAFUNCTIONS
{
    #region POST
    public class PostBodyAwards
    {
        public string id { get; set; }
        public int limit { get; set; }
        public int offset { get; set; }
    }
    #endregion

    #region POCO INPUT
    public class AwardsResponse
    {
        public string id { get; set; }
        public AwardsContainer awards { get; set; }
    }

    public class AwardsContainer
    {
        public string totalCount { get; set; }
        public List<AwardsElement> awardsList { get; set; }
    }

    public class AwardsElement
    {
        public string type { get; set; }
        public string title { get; set; }
        public string description { get; set; }
        public string date { get; set; }
        public string awardWon { get; set; }
        public string id { get; set; }
    }
    #endregion

    public static class Awards
    {
        [FunctionName("Awards")]
        public static async System.Threading.Tasks.Task<IActionResult> RunAsync(
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = "awards")]
            HttpRequestMessage req,
            [CosmosDB(
                databaseName: "contesthub",
                collectionName: "Awards",
                ConnectionStringSetting = "contesthub_DOCUMENTDB"
                )]
            DocumentClient client,
            TraceWriter log)
        {
            PostBodyAwards data = await req.Content.ReadAsAsync<PostBodyAwards>();
            log.Info($"Processed request for {data.id} in Profile, settingslimit: {data.limit},{data.limit}");

            log.Info($"Processed request for {data.id} in Awards");

            Uri collectionUri = UriFactory.CreateDocumentCollectionUri("contesthub", "Awards");

            IDocumentQuery<AwardsResponse> query = client.CreateDocumentQuery<AwardsResponse>(collectionUri)
                                                         .Where(d => d.id.ToUpper() == data.id.ToUpper()).AsDocumentQuery();

            // One result
            AwardsResponse item = null;
            while (query.HasMoreResults)
            {
                foreach (AwardsResponse result in await query.ExecuteNextAsync())
                {
                    item = result;
                    break;
                }
            }

            if (item == null) return new NoContentResult();

            else
            {
                item.awards.awardsList = item.awards.awardsList.Skip(((data.offset == 0 ? 1 : data.offset) - 1) * data.limit).Take(data.limit).ToList();
                return new OkObjectResult(item);
            }
        }
    }
}
