
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Documents.Client;
using Microsoft.Azure.Documents.Linq;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Host;

namespace DEVEBIAFUNCTIONS
{
    #region POCO INPUT
    public class ProfileInput
    {
        public string name { get; set; }
        public string role { get; set; }
        public string tenure { get; set; }
        public string email { get; set; }
        public string territory { get; set; }
        public string tvp { get; set; }
        public string marketOp { get; set; }
        public string mkd { get; set; }
        public string rsc { get; set; }
        public string dsc { get; set; }
        public string cit { get; set; }

    }
    #endregion
    public static class Profile
    {
        [FunctionName("Profile")]
        public static IActionResult Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", Route = "profile/{id}")]
                HttpRequest req,
            [CosmosDB(
                databaseName: "contesthub",
                collectionName: "Profile",
                ConnectionStringSetting = "contesthub_DOCUMENTDB",
                SqlQuery = "select * from Profile c where upper(c.id)=upper({id})"
                )]
            IEnumerable<ProfileInput> items,
            string id,
            TraceWriter log)
        {
            // c.name,c.role,c.tenure,c.email,c.territory,c.tvp,c.marketOp,c.mkd,c.rsc,c.dsc,c.cit
            log.Info($"Processed request for {id} in Profile");

            if (items == null || !items.Any())
            {
                log.Info($"No data");
                return new NoContentResult();
            }
            else
            {

                return new OkObjectResult(items.First());

            }
        }
    }

}
