
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Documents.Client;
using Microsoft.Azure.Documents.Linq;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Host;

namespace DEVEBIAFUNCTIONS
{

    #region CONSTANTS
    public enum ORDER
    {
        Ascending, Descending
    }

    public enum SORTBY
    {
        AP, Firstname, Lastname, Accounts, NoPay
    }

    public enum PERIOD
    {
        YTD, QTD, WTD
    }

    public enum ROLE
    {
        ASC, DSC
    }
    #endregion

    #region POCO INPUT
    public class TeamPerformance
    {
        public string id { get; set; }
        public string period { get; set; }
        public string role { get; set; }
        public TeamPerformanceDetails teamPerformanceDetails { get; set; }

    }

    public class TeamPerformanceDetails
    {
        public string totalCount { get; set; }
        public List<TeamPerformanceElement> teamPerformanceList { get; set; }
    }

    public class TeamPerformanceElement
    {
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string accounts { get; set; }
        public string ap { get; set; }
        public string noPay { get; set; }
    }

    #endregion

    #region POCO OUTPUT
    public class TeamPerformanceDetailsNoId
    {
        public string totalCount { get; set; }
        public List<TeamPerformanceElementNoRole> teamPerformanceList { get; set; }
    }

    public class TeamPerformanceElementNoRole
    {
        public TeamPerformanceElementNoRole(TeamPerformanceElement field)
        {
            this.firstName = field.firstName;
            this.lastName = field.lastName;
            this.accounts = field.accounts;
            this.ap = field.ap;
            this.noPay = field.noPay;
        }

        public string firstName { get; set; }
        public string lastName { get; set; }
        public string accounts { get; set; }
        public string ap { get; set; }
        public string noPay { get; set; }
    }

    public class TeamPerformanceNoId
    {
        public TeamPerformanceNoId(TeamPerformance teamPerformance)
        {
            TeamPerformanceDetails _teamPerformanceDetails = teamPerformance.teamPerformanceDetails;

            // Format names
            List<TeamPerformanceElementNoRole> newElem = new List<TeamPerformanceElementNoRole>();
            foreach (TeamPerformanceElement item in _teamPerformanceDetails.teamPerformanceList)
            {
                // Remove role
                newElem.Add(new TeamPerformanceElementNoRole(item));
            }

            this.teamPerformanceDetails = new TeamPerformanceDetailsNoId();
            this.teamPerformanceDetails.teamPerformanceList = newElem;
            this.teamPerformanceDetails.totalCount = teamPerformance.teamPerformanceDetails.totalCount;
        }
        public TeamPerformanceDetailsNoId teamPerformanceDetails { get; set; }
    }
    #endregion


    #region POST
    public class PostBody
    {
        public string id { get; set; }
        public ORDER sortOrder { get; set; }
        public SORTBY sortBy { get; set; }
        public int limit { get; set; }
        public ROLE role { get; set; }
        public PERIOD period { get; set; }
        public int offset { get; set; }
    }

    public static class TeamPerformanceFunc
    {
        [FunctionName("TeamPerformance")]
        public static async System.Threading.Tasks.Task<IActionResult> RunAsync(
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = "TeamPerformance")]
            HttpRequestMessage req,
            [CosmosDB(
                databaseName: "contesthub",
                collectionName: "TeamPerformance",
                ConnectionStringSetting = "contesthub_DOCUMENTDB"
                )]
            DocumentClient client,
            TraceWriter log)
        {
            // Parse body
            PostBody data = await req.Content.ReadAsAsync<PostBody>();
            log.Info($"Processed request for {data.id} in Profile, settings: sortOrder: {data.sortOrder}, sortBy: {data.sortBy}, limit: {data.limit}," +
$"role: {data.role}, period: {data.period}");

            // Query data
            Uri collectionUri = UriFactory.CreateDocumentCollectionUri("contesthub", "TeamPerformance");

            // filter WTD,QTD,YTD
            string id = $"{data.id}_{data.role}_{data.period}";
            IDocumentQuery<TeamPerformance> query = client.CreateDocumentQuery<TeamPerformance>(collectionUri)
                                                          .Where(d => d.id.ToUpper() == id.ToUpper()).AsDocumentQuery();
            //.Where(d => d.period == data.period.ToString()).AsDocumentQuery();

            // One result
            TeamPerformance item = null;
            while (query.HasMoreResults)
            {
                foreach (TeamPerformance result in await query.ExecuteNextAsync())
                {
                    item = result;
                    break;
                }
            }

            if (item == null) return new NoContentResult();

            // Offset -> 1, 2, 3...
            // Limit -> No. of records to be returned
            // Size -> Total no. of elements
            int size = item.teamPerformanceDetails.teamPerformanceList.Count();
            int limit = data.limit;
            int lower = data.offset;
            int fetchSize = limit;
            // Filter invalid input
            if (lower < 0) lower = 0;
            else lower -= 1;

            // Add current size as start position if it's not the first pull
            lower = lower * fetchSize;

            if (fetchSize > size)
            {
                // If the fetch size is bigger than the list, pull everything
                lower = 0;
                limit = size;
            }
            else if (lower > size - 1){
                // Invalid page
                return new NoContentResult();
            }
            else if (lower + fetchSize > size)
            {
                // If this is the last increment, overwrite
                // lower = size - fetchSize;
                limit = size - lower;
            }


            // Sort
            List<TeamPerformanceElement> sorted = new List<TeamPerformanceElement>();
            bool isAlreadySorted = false;
            // TODO: filter firstname/lastname empty
            if (data.sortBy == SORTBY.Firstname)
            {
                var fres = item.teamPerformanceDetails.teamPerformanceList
                               .Find(elem => elem.firstName == null || elem.firstName.Trim().Equals("-"));
                if (fres != null)
                {
                    if (data.sortOrder == ORDER.Descending)
                    {
                        sorted = item.teamPerformanceDetails.teamPerformanceList
                                     .OrderByDescending(elem => (elem.lastName)).ToList();
                    }
                    else if (data.sortOrder == ORDER.Ascending)
                    {
                        sorted = item.teamPerformanceDetails.teamPerformanceList
                                     .OrderBy(elem => (elem.lastName)).ToList();
                    }
                    isAlreadySorted = true;
                }
            }
            else if (data.sortBy == SORTBY.Lastname)
            {
                if (item.teamPerformanceDetails.teamPerformanceList
                    .Find(elem => elem.lastName == null || elem.lastName.Trim().Equals("-")) != null)
                {
                    if (data.sortOrder == ORDER.Descending)
                    {
                        sorted = item.teamPerformanceDetails.teamPerformanceList
                                     .OrderByDescending(elem => (elem.firstName)).ToList();
                    }
                    else if (data.sortOrder == ORDER.Ascending)
                    {
                        sorted = item.teamPerformanceDetails.teamPerformanceList
                                     .OrderBy(elem => (elem.firstName)).ToList();
                    }
                    isAlreadySorted = true;
                }
            }
            // Regular sorting
            if (data.sortBy == SORTBY.AP)
            {
                if (data.sortOrder == ORDER.Descending)
                {
                    sorted = item.teamPerformanceDetails.teamPerformanceList
                                 .OrderByDescending(elem => Convert.ToDouble(elem.ap.Replace("$", ""))).ToList();
                }
                else if (data.sortOrder == ORDER.Ascending)
                {
                    sorted = item.teamPerformanceDetails.teamPerformanceList
                                                              .OrderBy(elem => Convert.ToDouble(elem.ap.Replace("$", ""))).ToList();
                }
                else
                {
                    log.Warning("Order is not specified correctly");
                    return new NoContentResult();
                }
            }
            else if (data.sortBy == SORTBY.Firstname && !isAlreadySorted)
            {
               if (data.sortOrder == ORDER.Descending)
                {
                    sorted = item.teamPerformanceDetails.teamPerformanceList
                                 .OrderByDescending(elem => (elem.firstName)).ToList();
                }
                else if (data.sortOrder == ORDER.Ascending)
                {
                    sorted = item.teamPerformanceDetails.teamPerformanceList
                                 .OrderBy(elem => (elem.firstName)).ToList();
                }
                else
                {
                    log.Warning("Order is not specified correctly");
                    return new NoContentResult();
                }
            }
            else if (data.sortBy == SORTBY.Lastname && !isAlreadySorted)
            {
                if (data.sortOrder == ORDER.Descending)
                {
                    sorted = item.teamPerformanceDetails.teamPerformanceList
                                 .OrderByDescending(elem => (elem.lastName)).ToList();
                }
                else if (data.sortOrder == ORDER.Ascending)
                {
                    sorted = item.teamPerformanceDetails.teamPerformanceList
                                 .OrderBy(elem => (elem.lastName)).ToList();
                }
                else
                {
                    log.Warning("Order is not specified correctly");
                    return new NoContentResult();
                }
            }
            else if (data.sortBy == SORTBY.Accounts)
            {
                if (data.sortOrder == ORDER.Descending)
                {
                    sorted = item.teamPerformanceDetails.teamPerformanceList
                                 .OrderByDescending(elem => Convert.ToDouble(Convert.ToDouble(elem.accounts))).ToList();
                }
                else if (data.sortOrder == ORDER.Ascending)
                {
                    sorted = item.teamPerformanceDetails.teamPerformanceList
                                 .OrderBy(elem => Convert.ToDouble(Convert.ToDouble(elem.accounts))).ToList();
                }
                else
                {
                    log.Warning("Order is not specified correctly");
                    return new NoContentResult();
                }
            }
            else if (data.sortBy == SORTBY.NoPay)
            {
                if (data.sortOrder == ORDER.Descending)
                {
                    sorted = item.teamPerformanceDetails.teamPerformanceList
                                 .OrderByDescending(elem => Convert.ToDouble(Convert.ToDouble(elem.noPay.Replace("%", "")))).ToList();
                }
                else if (data.sortOrder == ORDER.Ascending)
                {
                    sorted = item.teamPerformanceDetails.teamPerformanceList
                                 .OrderBy(elem => Convert.ToDouble(Convert.ToDouble(elem.noPay.Replace("%", "")))).ToList();
                }
                else
                {
                    log.Warning("Order is not specified correctly");
                    return new NoContentResult();
                }
            }
            else if (!isAlreadySorted)
            {
				// default only
				sorted = item.teamPerformanceDetails.teamPerformanceList;
            }


            //limit feature
            
			item.teamPerformanceDetails.teamPerformanceList = sorted.Skip(((data.offset==0?1:data.offset) - 1) * data.limit).Take(data.limit).ToList();

            // Build as per specifications
            TeamPerformanceNoId finalRes = new TeamPerformanceNoId(item);

            // Return
            return new OkObjectResult(finalRes);
        }
    }
    #endregion
}
