
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Documents.Client;
using Microsoft.Azure.Documents.Linq;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Host;

namespace DEVEBIAFUNCTIONS
{

    #region CONSTANTS

    #endregion

    #region POCO INPUT
    public class rawAssociate
    {
        public string id { get; set; }
        public long seqRoleTerritoryMarket { get; set; }
        public string week { get; set; }
        public string quarter { get; set; }
        public string year { get; set; }
        public string territoryMarketOp { get; set; }
        public string isTerritory { get; set; }
        public string isMarket { get; set; }
        public string name { get; set; }
        public string role { get; set; }
        public string market { get; set; }
        public int currentRank { get; set; }
        public int maxRank { get; set; }
        public string ap { get; set; }
        public string noPay { get; set; }
        public string totalCount { get; set; }
    }
    #endregion

    #region POCO OUTPUT
    public class LeaderboardDetails
    {
        public LeaderboardDetails(rawAssociate asc, List<associate> associateList)
        {
            this.week = asc.week;
            this.quarter = asc.quarter;
            this.year = asc.year;
            this.territoryMarketOp = asc.territoryMarketOp;
            this.currentRank = asc.currentRank.ToString();
            this.maxRank = asc.maxRank.ToString();
            this.ap = asc.ap;
            this.noPay = asc.noPay;
			this.totalCount = asc.totalCount;
            this.associateList = associateList;
        }

        public string week { get; set; }
        public string quarter { get; set; }
        public string year { get; set; }
        public string territoryMarketOp { get; set; }
        public string currentRank { get; set; }
        public string maxRank { get; set; }
        public string ap { get; set; }
        public string noPay { get; set; }
        public string totalCount { get; set; }
        public List<associate> associateList { get; set; }

    }

    public class associate
    {
        public associate(rawAssociate asc)
        {
            this.rank = asc.currentRank.ToString();
            this.name = asc.name;
            this.market = asc.market;
            this.noPay = asc.noPay;
            this.ap = asc.ap;
            //this.maxRank = asc.maxRank.ToString();
            // TODO: temporary
            //this.seqRoleTerritoryMarket = asc.seqRoleTerritoryMarket;
        }

        public string rank { get; set; }
        public string name { get; set; }
        public string market { get; set; }
        public string noPay { get; set; }
        public string ap { get; set; }
        //public string maxRank { get; set; }
        // TODO: temporary
        //public long seqRoleTerritoryMarket { get; set; }
    }
    #endregion


    #region POST
    public class LeaderBoardPostBody
    {
        public string id { get; set; }
        public int offset { get; set; }
        public int limit { get; set; }
        public string isTerritory { get; set; }
        public string isMarketOp { get; set; }
        public string searchText { get; set; }
    }

    public static class LeaderBoardFunc
    {
        [FunctionName("LeaderBoard")]
        public static async System.Threading.Tasks.Task<IActionResult> RunAsync(
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = "LeaderBoard")]
            HttpRequestMessage req,
            [CosmosDB(
                databaseName: "contesthub",
                collectionName: "LeaderBoard",
                ConnectionStringSetting = "contesthub_DOCUMENTDB"
                )]
            DocumentClient client,
            TraceWriter log)
        {
            // Parse body
            LeaderBoardPostBody data = await req.Content.ReadAsAsync<LeaderBoardPostBody>();
            log.Info($"Processed request for {data.id} in LeaderBoard, settings: limit: {data.limit}, isTerritory: {data.isTerritory}, isMarketOp: {data.isMarketOp}," +
                     $"searchText: {data.searchText}");

            // Query data
            Uri collectionUri = UriFactory.CreateDocumentCollectionUri("contesthub", "LeaderBoard");

            // Get top level associate
            // Prepare id filter
            string id = data.id.ToUpper();
            if (!Convert.ToBoolean(data.isMarketOp.ToLower()) ^ Convert.ToBoolean(data.isTerritory.ToLower())) return new BadRequestResult();

            //check search string length if its a search query
            if (!string.IsNullOrEmpty(data.searchText) && data.searchText.Length < 3)
            {
                return new BadRequestResult();
            }

            if (Convert.ToBoolean(data.isTerritory.ToLower())) id += "_T";
            else id += "_M";
            IDocumentQuery<rawAssociate> query = client.CreateDocumentQuery<rawAssociate>(collectionUri)
                                                          .Where(d => d.id.ToUpper() == id.ToUpper())
                                                       .AsDocumentQuery();

            // One result
            rawAssociate item = null;
            while (query.HasMoreResults)
            {
                foreach (rawAssociate result in await query.ExecuteNextAsync())
                {
                    item = result;
                    break;
                }
            }

            if (item == null) return new NoContentResult();

            // Get offset
            int offset = (data.offset == 0) ? 0 : data.offset - 1;

            // Get sublist 
            IDocumentQuery<rawAssociate> subLevelQuery = null;
            if (string.IsNullOrEmpty(data.searchText))
            {
                subLevelQuery = client.CreateDocumentQuery<rawAssociate>(collectionUri, new FeedOptions { MaxItemCount = data.limit })
                                      .Where(d => d.role.ToLower() == item.role.ToLower())
                                      .Where(d => d.isTerritory.ToLower() == data.isTerritory.ToLower())
                                      .Where(d => d.isMarket.ToLower() == data.isMarketOp.ToLower())
                                      .Where(d => d.seqRoleTerritoryMarket > offset * data.limit)
                                      .OrderBy(d => d.seqRoleTerritoryMarket)
                                      //.Skip((offset-1) *data.limit)
                                      .Take(data.limit)
                                      .AsDocumentQuery();
            }
            else
            {
                subLevelQuery = client.CreateDocumentQuery<rawAssociate>(collectionUri, new FeedOptions { MaxItemCount = data.limit })
                                      .Where(d => d.role.ToLower() == item.role.ToLower())
                                      .Where(d => d.isTerritory.ToLower() == data.isTerritory.ToLower())
                                      .Where(d => d.isMarket.ToLower() == data.isMarketOp.ToLower())
                                      .Where(d => d.name.ToLower().Contains(data.searchText.ToLower()))
                                      //.Where(d => d.seqRoleTerritoryMarket > offset * data.limit)
                                      .OrderBy(d => d.currentRank)
                                      //.Skip((offset - 1) * data.limit)
                                      //.Take(data.limit)
                                      .AsDocumentQuery();
            }

            // Build target
            List<associate> associateList = new List<associate>();
            List<associate> filteredAssociateList = new List<associate>();
            while (subLevelQuery.HasMoreResults)
            {
                foreach (rawAssociate result in await subLevelQuery.ExecuteNextAsync())
                {
                    associateList.Add(new associate(result));
                }
            }

            // Offset in-memory for search queries
            if (!string.IsNullOrEmpty(data.searchText))
            {
                var lower = offset * data.limit;
                var upper = data.limit;
                if (lower + upper > associateList.Count || lower >= associateList.Count)
                {
                    lower = offset * data.limit;
                    upper = associateList.Count - lower;
                    if (lower + upper > associateList.Count || lower >= associateList.Count)
                    {
                        return new NoContentResult();
                    }
                }
                // Limit
                associateList = associateList.GetRange(lower, upper);
            }

            LeaderboardDetails leaderboardDetails = new LeaderboardDetails(item, associateList);

            // Return
            return new OkObjectResult(leaderboardDetails);
        }
    }
    #endregion
}
