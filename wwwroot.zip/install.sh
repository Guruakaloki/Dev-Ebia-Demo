#!/bin/zsh

# https://docs.microsoft.com/en-us/azure/azure-functions/functions-run-local#install-the-azure-functions-core-tools
func azure functionapp publish DEV-EBIA-FUNCTIONS-2